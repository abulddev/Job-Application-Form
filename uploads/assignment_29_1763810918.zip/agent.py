import logging
import os
import time
from pathlib import Path
from dynaconf import Dynaconf
from langchain_core.agents import AgentFinish
from langchain.agents.output_parsers.tools import ToolAgentAction
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.agents.format_scratchpad.openai_tools import format_to_openai_tool_messages
from langchain.agents.output_parsers.openai_tools import OpenAIToolsAgentOutputParser
from data_models import MessagesList
from tools import execute_sql_query, execute_sql_query_imp


def get_tables_metadata(settings: Dynaconf):
    """Reads and returns the table metadata from the specified file."""
    with open(settings.get("METADATA_PATH"), "r", encoding="utf-8") as file:
        metadata = file.read()
    return metadata

def sql_agent(settings: Dynaconf, logger: logging.Logger, db_conn_str: str, conversation: MessagesList) -> str:
    """
    The main function for the SQL agent.
    """
    try:
        metadata = get_tables_metadata(settings)
        os.environ["GROQ_API_KEY"] = settings.get("GROQ_API_KEY")
        llm = ChatGroq(model="meta-llama/llama-4-maverick-17b-128e-instruct", temperature=0)

        tools = [
            execute_sql_query
        ]

        system_prompt = Path("system_prompt.txt").read_text(encoding="utf-8")

        user_prompt = """
Conversation:
{conversation}
        """
        agent_prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_prompt),
                ("user", user_prompt),
                MessagesPlaceholder(variable_name="agent_scratchpad"),
            ]
        )

        llm_with_tools = llm.bind_tools(tools)

        agent = (
                {
                    "conversation": lambda x: x["conversation"],
                    "metadata": lambda x: x["metadata"],
                    "agent_scratchpad": lambda x: format_to_openai_tool_messages(
                        x["intermediate_steps"]
                    ),
                }
                | agent_prompt
                | llm_with_tools
                | OpenAIToolsAgentOutputParser()
        )

        prompt_input = {
            "conversation": conversation,
            "metadata": metadata,
            "intermediate_steps": []
        }
        
        testing_prompt = agent_prompt.format(**{
            "conversation": prompt_input["conversation"],
            "metadata": prompt_input["metadata"],
            "agent_scratchpad": format_to_openai_tool_messages(prompt_input["intermediate_steps"])
        })
        logger.debug(f"Initial prompt:\n{testing_prompt}")

        agent_invoke_start_time = time.time()
        output = agent.invoke(prompt_input)
        logger.info(f"agent.invoke took {time.time() - agent_invoke_start_time:.2f} seconds")
        logger.info(output)

        while not isinstance(output, AgentFinish):
            for selected_tool in output:
                logger.info("Tool call:     --->    " + selected_tool.log.strip())
                if isinstance(selected_tool, ToolAgentAction):
                    name = selected_tool.tool
                    tool_input = selected_tool.tool_input

                    if name == "execute_sql_query":
                        start_time = time.time()
                        tool_output = execute_sql_query_imp(settings, logger, db_conn_str, **tool_input)
                        elapsed_time = time.time() - start_time
                        logger.info(f"execute_sql_query_imp took {elapsed_time:.2f} seconds")
                    else:
                        tool_output = f"Unknown tool: {name}"

                    logger.info("Observation:   --->    " + str(tool_output))
                    prompt_input["intermediate_steps"].append((
                        selected_tool, tool_output
                    ))

            testing_prompt = agent_prompt.format(**{
                "conversation": prompt_input["conversation"],
                "metadata": prompt_input["metadata"],
                "agent_scratchpad": format_to_openai_tool_messages(prompt_input["intermediate_steps"])
            })
            logger.debug(f"Next prompt:\n{testing_prompt}")

            agent_invoke_start_time = time.time()
            output = agent.invoke(prompt_input)
            logger.info(f"agent.invoke took {time.time() - agent_invoke_start_time:.2f} seconds")
            logger.info(output)

        return output.return_values['output']
    except Exception as e:
        logger.warning(f"Error in sql agent:\n{(str(e))}")
        return f"Error in sql agent:\n{str(e)}"

