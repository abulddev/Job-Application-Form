from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.chat_history import InMemoryChatMessageHistory
from langchain_core.runnables import RunnableWithMessageHistory
from config import GEMINI_KEY

# Initialize LLM
llm = ChatGoogleGenerativeAI(
    model="gemini-2.0-flash",
    google_api_key=GEMINI_KEY,
    temperature=0.5
)

# Prompt Template
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a friendly chatbot that remembers everything user says, including their name."),
    MessagesPlaceholder(variable_name="history"),
    ("human", "{input}")
])

# Runnable with Message History
chat = RunnableWithMessageHistory(
    prompt | llm,
    lambda session_id: InMemoryChatMessageHistory(),
    input_messages_key="input",
    history_messages_key="history"
)
