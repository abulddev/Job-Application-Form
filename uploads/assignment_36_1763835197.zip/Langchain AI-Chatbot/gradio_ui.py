import gradio as gr
from auth import login_user, register_user
from chat_management import get_session_history, save_session_history, create_new_session, get_user_sessions
from ai_setup import chat
from db import users_col

# Gradio Functions
def respond(message, chat_history, username, session_id):
    if not message.strip():
        return chat_history, ""

    hist = get_session_history(username, session_id)
    hist.add_user_message(message)
    user_doc = users_col.find_one({"username": username})
    stored_name = user_doc.get("name") if user_doc else None

    message_lower = message.lower().replace("’", "'").strip()
    response_text = None

    if "my name is" in message_lower:
        extracted_name = message_lower.split("my name is")[-1].strip().split()[0].capitalize()
        users_col.update_one({"username": username}, {"$set": {"name": extracted_name}})
        stored_name = extracted_name
        response_text = f"It's great to meet you, {stored_name}! I'll remember your name."

    elif any(phrase in message_lower for phrase in [
        "what is my name", "what's my name", "whats my name",
        "do you know my name", "who am i", "tell me my name", "remember my name"
    ]):
        response_text = f"Your name is {stored_name}!" if stored_name else "I don't know your name yet! You haven't told me. What should I call you?"

    elif any(greet in message_lower.split() for greet in ["hello", "hi", "hey"]):
        response_text = f"Hello {stored_name}! How can I help you today?" if stored_name else "Hello! I don’t know your name yet. What should I call you?"

    if response_text is None:
        response = chat.invoke({"input": message}, config={"configurable": {"session_id": session_id}})
        response_text = response.content

    # Update session title
    user_doc = users_col.find_one({"username": username})
    updated = False
    for s in user_doc.get("sessions", []):
        if s["id"] == session_id and (s["name"].startswith("New Chat") or not s["name"]):
            new_name = message[:40].capitalize()
            users_col.update_one(
                {"username": username, "sessions.id": session_id},
                {"$set": {"sessions.$.name": new_name}}
            )
            updated = True
            break

    hist.add_ai_message(response_text)
    save_session_history(username, session_id, hist)

    chat_history += [
        {"role": "user", "content": message},
        {"role": "assistant", "content": response_text}
    ]

    if updated:
        sessions = get_user_sessions(username)
        choices = [s["name"] for s in sessions]
        return chat_history, "", gr.update(choices=choices, value=new_name)
    else:
        return chat_history, "", gr.update()
