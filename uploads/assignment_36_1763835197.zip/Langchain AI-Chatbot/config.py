from dotenv import load_dotenv
import os

load_dotenv()

GEMINI_KEY = os.getenv("GEMINI_API_KEY")
MONGO_URI = os.getenv("MONGO_URI")

if not GEMINI_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env file!")
if not MONGO_URI:
    raise ValueError("MONGO_URI not found in .env file!")
