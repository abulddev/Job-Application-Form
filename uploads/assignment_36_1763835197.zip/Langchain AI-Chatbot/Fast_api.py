from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from auth import login_user, register_user, save_user_name
from chat_management import get_user_sessions, create_new_session, get_session_history, save_session_history
from ai_setup import chat
from db import users_col
import uvicorn

app = FastAPI(title="Memory Chatbot API")

# ------------------ Pydantic Models ------------------ #
class UserCredentials(BaseModel):
    username: str
    password: str

class ChatMessage(BaseModel):
    username: str
    session_id: str
    message: str

class NewSessionRequest(BaseModel):
    username: str
    first_message: Optional[str] = None

# ------------------ User Endpoints ------------------ #
@app.post("/register")
def api_register(credentials: UserCredentials):
    msg = register_user(credentials.username, credentials.password)
    if "successfully" in msg.lower():
        return {"status": "success", "message": msg}
    raise HTTPException(status_code=400, detail=msg)

@app.post("/login")
def api_login(credentials: UserCredentials):
    if login_user(credentials.username, credentials.password):
        return {"status": "success", "message": "Login successful!"}
    raise HTTPException(status_code=401, detail="Invalid username or password!")

# ------------------ Session Endpoints ------------------ #
@app.get("/sessions/{username}")
def api_get_sessions(username: str):
    sessions = get_user_sessions(username)
    return [{"id": s["id"], "name": s["name"]} for s in sessions]

@app.get("/")
def root():
    return {"message": "Memory Chatbot API is running! Use /docs to test endpoints."}

@app.post("/sessions/new")
def api_create_session(req: NewSessionRequest):
    session_id, session_name = create_new_session(req.username, req.first_message)
    return {"id": session_id, "name": session_name}

# ------------------ Chat Endpoint ------------------ #
@app.post("/chat")
def api_chat(message: ChatMessage):
    hist = get_session_history(message.username, message.session_id)
    hist.add_user_message(message.message)
    user_doc = users_col.find_one({"username": message.username})
    stored_name = user_doc.get("name") if user_doc else None

    message_lower = message.message.lower().replace("’", "'").strip()
    response_text = None

    # Name handling
    if "my name is" in message_lower:
        extracted_name = message_lower.split("my name is")[-1].strip().split()[0].capitalize()
        save_user_name(message.username, extracted_name)
        stored_name = extracted_name
        response_text = f"It's great to meet you, {stored_name}! I'll remember your name."
    elif any(phrase in message_lower for phrase in [
        "what is my name", "what's my name", "whats my name",
        "do you know my name", "who am i", "tell me my name", "remember my name"
    ]):
        response_text = f"Your name is {stored_name}!" if stored_name else "I don't know your name yet!"
    elif any(greet in message_lower.split() for greet in ["hello", "hi", "hey"]):
        response_text = f"Hello {stored_name}! How can I help you today?" if stored_name else "Hello! I don’t know your name yet."

    if response_text is None:
        response = chat.invoke({"input": message.message}, config={"configurable": {"session_id": message.session_id}})
        response_text = response.content

    # Update session title if first message
    updated = False
    user_doc = users_col.find_one({"username": message.username})
    for s in user_doc.get("sessions", []):
        if s["id"] == message.session_id and (s["name"].startswith("New Chat") or not s["name"]):
            new_name = message.message[:40].capitalize()
            users_col.update_one(
                {"username": message.username, "sessions.id": message.session_id},
                {"$set": {"sessions.$.name": new_name}}
            )
            updated = True
            break

    hist.add_ai_message(response_text)
    save_session_history(message.username, message.session_id, hist)

    return {"response": response_text, "session_updated": updated}

# ------------------ Delete Session ------------------ #
@app.delete("/sessions/{username}/{session_name}")
def api_delete_session(username: str, session_name: str):
    if not session_name:
        raise HTTPException(status_code=400, detail="Session name required")
    users_col.update_one({"username": username}, {"$pull": {"sessions": {"name": session_name}}})
    return {"status": "success", "message": f"Session '{session_name}' deleted"}

# ------------------ Run Uvicorn automatically ------------------ #
def main():
    uvicorn.run("Fast_api:app", host="127.0.0.1", port=8000, reload=True)

if __name__ == "__main__":
    main()
